﻿//Andrew McQuillen
//CIS 200
//Due 6/11/15
//Program 2: this program takes user input data through a GUI application.
//there are 3 forms, the letter form and the address form store data in their respective lists.
//the letter form uses combo boxes to save user created addresses and hard coded address.
//the main form runs the other two forms and displays generated reports

//Program2MainForm.cs
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class Program2MainForm : Form
    {
        //Initialize address list and parcel list
         private List<Address> addressList = new List<Address>();
         private List<Parcel> parcels = new List<Parcel>();

        public Program2MainForm()
        {
            InitializeComponent();
            //List of addresses
            Address a1 = new Address("John Smith", "123 Any St.", "Apt. 45",
                "Louisville", "KY", 40202);
            Address a2 = new Address("Jane Doe", "987 Main St.", "",
                "Beverly Hills", "CA", 90210);
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901);
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 14101);
            Address a5 = new Address("Bob Dole", "456 Viagra Lane", "",
                    "Russell", "KS", 67665);
            Address a6 = new Address("Sheldon Cooper", "2300 Los Robles Road", "Apr. 4A",
                "Pasadena", "CA", 90041);
            Address a7 = new Address("Danny Tanner", "1709 Broderick Street", "",
                "San Francisco", "CA", 94115);
            Address a8 = new Address("Rachel Green", "90 Bedford St.", "Apt. 20",
                "New York", "NY", 10014);
            //add addresses to list
            addressList.Add(a1);
            addressList.Add(a2);
            addressList.Add(a3);
            addressList.Add(a4);
            addressList.Add(a5);
            addressList.Add(a6);
            addressList.Add(a7);
            addressList.Add(a8);
            //List of Letters
            Letter letter1 = new Letter(a1, a2, 40);
            Letter letter2 = new Letter(a3, a4, 10);
            GroundPackage gp1 = new GroundPackage(a5, a6, 14, 10, 5, 12.5);
            NextDayAirPackage ndap1 = new NextDayAirPackage(a7, a8, 25, 15, 15,
                85, 7.50M);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a1, a8, 19.3, 22.5, 4.9,
                79.5, TwoDayAirPackage.Delivery.Early);
            //add parcels to list
            parcels.Add(letter1);
            parcels.Add(letter2);
            parcels.Add(gp1);
            parcels.Add(ndap1);
            parcels.Add(tdap2);
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Displays basic information when the about button is clicked within file
            //about is accessible by ctrl+A
            MessageBox.Show("AJ McQuillen\nCIS 200\nProgram 2");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Exits the application from the Exit button under file
            //Exit is accessible by ctrl+E
            Application.Exit();
        }

        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Modal form Address shows up when clicked
            AddressForm addressForm = new AddressForm();
            DialogResult result;
            result = addressForm.ShowDialog();
            //properties defined for address list
            string name;
            string address1;
            string address2;
            string city;
            string state;
            int zip;
            // validates the ok and cancel button
            if (result == DialogResult.OK)
            {
                //calls the properties from the address form and stores them in variables.
                name = addressForm.Names;
                address1 = addressForm.Address1;
                address2 = addressForm.Address2;
                city = addressForm.City;
                state = addressForm.State;
                zip = int.Parse(addressForm.Zip);
                //adds user input data into the address list
                Address address;
                address = new Address(name, address1, address2, city, state, zip);
                addressList.Add(address);
            }
        }

        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //modal dialog form Letter shows up when clicked
            LetterForm letterForm = new LetterForm(addressList);
            DialogResult result;
            result = letterForm.ShowDialog();
            //properties defined for parcel list
            Address oAddress;
            Address dAddress;
            decimal fCost;
            //Validates the OK and cancel button
            if (result == DialogResult.OK) 
            {
                //calls the properties from the letter form. Recognizes the index selected in the letter form
                oAddress = addressList[letterForm.OriginAddressIndex];
                dAddress = addressList[letterForm.DestAddressIndex];
                fCost = decimal.Parse(letterForm.FixedCost);
               
                //if the origin address does not equal the destination address, the letter is stored in the parcel list 
                Letter letter;
                letter = new Letter(oAddress, dAddress, fCost);
                parcels.Add(letter);
            }
        }

        private void listAddressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                //foreach loop steps through address list
                reportBox.Clear();
                foreach (var a in addressList)
                {
                    //all data from address list is displayed on the main form textbox
                    reportBox.AppendText(Environment.NewLine + a + Environment.NewLine);
                }
            }
        }

        private void listLetterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //foreach loop steps through the parcel list
            decimal cost = 0;
            reportBox.Clear();
            foreach (var p in parcels)
            {
                //running total of cost is calculated and parcel list is displayed
                cost += p.CalcCost();
                reportBox.AppendText(p.ToString() + Environment.NewLine );
            }
            //total cost is displayed at the bottom of the textbox
            reportBox.AppendText("Total Cost = " + cost.ToString("c"));
        }
    }
}
