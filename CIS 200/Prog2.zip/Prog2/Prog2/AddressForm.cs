﻿//Program 2 AddressForm.cs
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{

    public partial class AddressForm : Form
    {
       //initializes address form
        public AddressForm()
        {
            InitializeComponent();
        }
        public string Names
        {
            //get set properties for Name field
            get { return nameBox.Text; }
            set { nameBox.Text = value; }
        }
        public string Address1
        {
            //get set properties for address 1 field
            get { return address1Box.Text; }
            set { address1Box.Text = value; }
        }
        public string Address2
        {
            //get set properties for address 2 field
            get { return address2Box.Text; }
            set { address2Box.Text = value; }
        }
        public string City
        {
            //get set properties for city
            get { return cityBox.Text; }
            set { cityBox.Text = value; }
        }
        public string State
        {
            //get set properties for state
            get { return stateComboBox.Text; }
            set { stateComboBox.Text = value; }
        }
        public string Zip
        {
            //get set properties for zip
            get { return zipBox.Text; }
            set { zipBox.Text = value; }
        }
        //error validated. shows no error if there is no error
        private void nameBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(nameBox, "");
        }

        private void address1Box_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(address1Box, "");
        }

        private void cityBox_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(cityBox, "");
        }

        private void zipBox_Validated(object sender, EventArgs e)
        {
            errorProvider4.SetError(zipBox, "");
        }
        //error validating. will show error and keep focus on field that has not been completed
        //will not allow advancement until field is completed
        private void nameBox_Validating(object sender, CancelEventArgs e)
        {
            string name;
            name = nameBox.Text;
            if (string.IsNullOrEmpty(nameBox.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(nameBox, "Enter a Name!");
                nameBox.SelectAll();
            }
        }

        private void address1Box_Validating(object sender, CancelEventArgs e)
        {
            string address1;
            address1 = address1Box.Text;
            if (string.IsNullOrEmpty(address1Box.Text))
            {
                e.Cancel = true;
                errorProvider2.SetError(address1Box, "Enter an Address!");
                address1Box.SelectAll();
            }
        }

        private void cityBox_Validating(object sender, CancelEventArgs e)
        {
            string city;
            city = cityBox.Text;
            if (string.IsNullOrEmpty(cityBox.Text))
            {
                e.Cancel = true;
                errorProvider3.SetError(cityBox, "Enter a City!");
                cityBox.SelectAll();
            }
        }

        private void zipBox_Validating(object sender, CancelEventArgs e)
        {
            int zip;
            //ensures zip code field is a number
            if (!int.TryParse(zipBox.Text, out zip))
            {
                e.Cancel = true;
                errorProvider4.SetError(zipBox, "Enter Valid Zip Code!");
                zipBox.SelectAll();
            }
            else
            {
                //ensures that zip code field is exactly 5 numbers long
                if (zip.ToString().Length != 5)
                {
                    e.Cancel = true;
                    errorProvider4.SetError(zipBox, "Enter Valid Zip Code!");
                    zipBox.SelectAll();
                }
            }
        }

        private void stateComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider5.SetError(stateComboBox, "");
        }

        private void stateComboBox_Validating(object sender, CancelEventArgs e)
        {
            string state;
            state = stateComboBox.Text;
            if (string.IsNullOrEmpty(stateComboBox.Text))
            {
                e.Cancel = true;
                errorProvider5.SetError(stateComboBox, "Select or add a State!");
                cityBox.SelectAll();
            }
        }

        private void cancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            //allows left mouse click cancel 
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            //validates ok button
            if (this.ValidateChildren())
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }
    }
}
