﻿//Program 2 LetterForm.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class LetterForm : Form 
    {
        //address list accessor
        List<Address> _addressList;
        //address list is the constructor
        public LetterForm(List<Address> addressList)
        {
            InitializeComponent();
            _addressList = addressList;//accessor for the constructor
        }
        public int OriginAddressIndex//get and set for the origin combo box index
        {
            get { return oAComboBox.SelectedIndex; }
            set { oAComboBox.SelectedIndex = value; }
        }
        public int DestAddressIndex//get and set for the destination combo box index
        {
            get { return dAComboBox.SelectedIndex; }
            set { dAComboBox.SelectedIndex = value; }
        }
        public string FixedCost//get and set for the fixed cost text box
        {
            get { return fCBox.Text; }
            set { fCBox.Text = value; }
        }
        private void oAComboBox_Validated(object sender, EventArgs e)
        {
            //Error validated. no error shown when no error 
            errorProvider1.SetError(oAComboBox, "");
        }

        private void oAComboBox_Validating(object sender, CancelEventArgs e)
        {
            //Error validating. Keeps focus on Origin Address combo box until properly filled

            string oA;
            oA = oAComboBox.Text;
            if (string.IsNullOrEmpty(oAComboBox.Text))
            {
                //allows form to be canceled if improperly filled but advancing to Ok or new field is not allowed
                e.Cancel = true;
                errorProvider1.SetError(oAComboBox, "Select an Origin Address!");
                oAComboBox.SelectAll();
            }
            //error if Destination address = origin address.
            if (oAComboBox.Text == dAComboBox.Text)
            {
                e.Cancel = true;
                errorProvider1.SetError(oAComboBox, "Origin Address Must be different than Destination Address!");
                oAComboBox.SelectAll();
            }
        }

        private void dAComboBox_Validated(object sender, EventArgs e)
        {
            //Error validated. no error shown when no error
            errorProvider2.SetError(dAComboBox, "");
        }

        private void dAComboBox_Validating(object sender, CancelEventArgs e)
        {
            //Error Validating. Keeps focus on Destination Address combo box until properly filled
            string dA;
            dA = dAComboBox.Text;
            if (string.IsNullOrEmpty(dAComboBox.Text))
            {
                //allows form to be canceled if improperly filled but advancing to ok or new field is not allowed
                e.Cancel = true;
                errorProvider2.SetError(dAComboBox, "Select a Destination Address!");
                dAComboBox.SelectAll();
                //error if destination address = origin address
            } if (oAComboBox.Text == dAComboBox.Text)
            {
                e.Cancel = true;
                errorProvider2.SetError(dAComboBox, "Origin Address Must be different than Destination Address!");
                dAComboBox.SelectAll();
            }
        }

        private void fCBox_Validated(object sender, EventArgs e)
        {
            //Error validated. no error shown when no error
            errorProvider3.SetError(fCBox, "");
        }

        private void fCBox_Validating(object sender, CancelEventArgs e)
        {
            //Error Validating. Keeps focus on fixed cost box until properly filled
            decimal fC;
            if (!decimal.TryParse(fCBox.Text, out fC))
            {
                //allows form to be canceled if improperly filled but advancing to ok or new field is not allowed
                e.Cancel = true;
                errorProvider3.SetError(fCBox, "Enter Valid Fixed Cost!");
                fCBox.SelectAll();
            }
            else
            {
                //fixed cost must be greater than 0
                if(fC < 0)
                {
                    e.Cancel = true;
                    errorProvider3.SetError(fCBox,"Enter Valid Fixed Cost!");
                    fCBox.SelectAll();
                }
            }
        }
        private void letterFormCancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            //allows cancel button to be clicked and cancel the form
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }

        private void letterFormOkBtn_Click(object sender, EventArgs e)
        {
            //allows ok button to be clicked and accept the form
            if (this.ValidateChildren())
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void LetterForm_Load(object sender, EventArgs e)
        {
            //foreach loop adds list of addresses to the origin and destination combo box
            foreach (var a in _addressList)
            {
                oAComboBox.Items.Add(a.Name);
                dAComboBox.Items.Add(a.Name);
            }
            
        }
    }
}
