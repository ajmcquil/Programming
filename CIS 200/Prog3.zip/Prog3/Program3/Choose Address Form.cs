﻿// Program 2
// CIS 200
// Summer 2015
// Due: 6/11/2015
// By: AJ McQuillen 

// File: ChooseAddressForm.cs
// This class creates the Choose Address Form for editing Addresses. It performs validation and 
// provides properties for each field.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class Choose_Address_Form : Form
    {
        private List<Address> addressList; // List of Addresses used to fill combo boxes
        public const int MIN_ADDRESSES = 2; // Minimum number of addresses needed

        // Precondition:  List addresses is populated with the available
        //                addresses (at least 2) to choose from
        // Postcondition: The form's GUI is prepared for display
        public Choose_Address_Form(List<Address> addresses)
        {
            InitializeComponent();
            addressList = addresses;
        }
        
        public int EditAddressIndex
        {
            // Preconditions: user has selected an index from the editComboBox
            // Postcondition: the index of the selected index is returned
            get
            {
                return editComboBox.SelectedIndex;
            }
            // Precondition:  -1 <= value < addressList.Count
            // Postcondition: The specified index is selected in editComboBox
            set
            {
                if ((value >= -1) && (value < addressList.Count))
                    editComboBox.SelectedIndex = value;
                else
                    throw new ArgumentOutOfRangeException("OriginAddressIndex", value,
                        "Index must be valid");
            }
        }

        private void editOkbtn_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }
        // Precondition:  addressList.Count >= MIN_ADDRESSES
        // Postcondition: The list of addresses is used to populate the
        //                origin and destination address combo boxes
        private void Choose_Address_Form_Load(object sender, EventArgs e)
        {
            if (addressList.Count < MIN_ADDRESSES) // Violated precondition!
            {
                MessageBox.Show("Need " + MIN_ADDRESSES + " addresses to create letter!",
                    "Addresses Error");
                this.DialogResult = DialogResult.Abort; // Dismiss immediately
            }
            else
            {
                foreach (Address a in addressList)
                {
                    editComboBox.Items.Add(a.Name);
                }
            }
        }

        private void editComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(editComboBox, "");

        }
        // Precondition:  Focus on the editCOmboBox
        // Postcondition: If no address selected, focus remains and error provider
        //                highlights the field

        private void editComboBox_Validating(object sender, CancelEventArgs e)
        {
            string editAddress;
            editAddress = editComboBox.Text;
            if (string.IsNullOrEmpty(editComboBox.Text))
            {
                //allows form to be canceled if improperly filled but advancing to Ok or new field is not allowed
                e.Cancel = true;
                errorProvider1.SetError(editComboBox, "Select an Origin Address!");
                editComboBox.SelectAll();
            }

        }
        // Precondition:  User pressed on cancelBtn
        // Postcondition: Form closes
        private void editCancelBtn_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }
    }
}
