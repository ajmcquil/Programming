﻿namespace Prog2
{
    partial class Choose_Address_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.editComboBox = new System.Windows.Forms.ComboBox();
            this.editOkbtn = new System.Windows.Forms.Button();
            this.editCancelBtn = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose Address To Edit:";
            // 
            // editComboBox
            // 
            this.editComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.editComboBox.FormattingEnabled = true;
            this.editComboBox.Location = new System.Drawing.Point(63, 25);
            this.editComboBox.Name = "editComboBox";
            this.editComboBox.Size = new System.Drawing.Size(121, 21);
            this.editComboBox.TabIndex = 1;
            this.editComboBox.Validating += new System.ComponentModel.CancelEventHandler(this.editComboBox_Validating);
            this.editComboBox.Validated += new System.EventHandler(this.editComboBox_Validated);
            // 
            // editOkbtn
            // 
            this.editOkbtn.Location = new System.Drawing.Point(21, 52);
            this.editOkbtn.Name = "editOkbtn";
            this.editOkbtn.Size = new System.Drawing.Size(75, 23);
            this.editOkbtn.TabIndex = 2;
            this.editOkbtn.Text = "OK";
            this.editOkbtn.UseVisualStyleBackColor = true;
            this.editOkbtn.Click += new System.EventHandler(this.editOkbtn_Click);
            // 
            // editCancelBtn
            // 
            this.editCancelBtn.Location = new System.Drawing.Point(150, 52);
            this.editCancelBtn.Name = "editCancelBtn";
            this.editCancelBtn.Size = new System.Drawing.Size(75, 23);
            this.editCancelBtn.TabIndex = 3;
            this.editCancelBtn.Text = "Cancel";
            this.editCancelBtn.UseVisualStyleBackColor = true;
            this.editCancelBtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.editCancelBtn_MouseDown);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Choose_Address_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(247, 80);
            this.Controls.Add(this.editCancelBtn);
            this.Controls.Add(this.editOkbtn);
            this.Controls.Add(this.editComboBox);
            this.Controls.Add(this.label1);
            this.Name = "Choose_Address_Form";
            this.Text = "Choose Address";
            this.Load += new System.EventHandler(this.Choose_Address_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox editComboBox;
        private System.Windows.Forms.Button editOkbtn;
        private System.Windows.Forms.Button editCancelBtn;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}