﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class ExtraCredit : IComparer<Parcel>
    {
        // Precondition: IComparer class defined
        // Postcondition: set order for type ascending and cost descending 
        public int Compare(Parcel p1, Parcel p2)
        {
            if (p2 == null && p1 == null)
            {// Both null?
                return 0;
            }
            if (p2 == null)
            {// only this is null?
                return -1;
            }
            if (p1 == null)
            {// only t2 is null?
                return 1;
            }
            // compare the types, if the types are different group the type in ascending order
            int typeCompare = String.Compare(p1.GetType().ToString(), p2.GetType().ToString());
            if (typeCompare != 0)
            return typeCompare;
            // when the types are the same, list the types in cost descending order
            decimal costCompare = p1.CalcCost() - p2.CalcCost();
            if (costCompare > 0)
                return -1;
            else if (costCompare < 0)
                return 1;
            return 0;
            
            
        }
    }
}
