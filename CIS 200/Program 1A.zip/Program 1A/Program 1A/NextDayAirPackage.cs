﻿// Program 1A
// CIS 200
// Due: 5/31/15
// By: AJ McQuillen

// File: NextDayAirPackage.cs

// concrete class derived from AirPackage.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    public class NextDayAirPackage : AirPackage
    {
        public decimal expressFee;
        // Preconditions: cost >= 0
        // Postconditions: The nextdayairpackage is created with the specified values
        // from the base class
        public NextDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height,
            double weight, decimal expressFee, bool IsHeavy,bool IsLarge)
            : base(originAddress, destAddress, length, weight, width, height)
        {
            ExpressFee = expressFee;
        }
        public decimal ExpressFee
            // Precondtions: none
            // Postconditions: the express fee is determined
        {
            get
            {
                return expressFee;
            }
            private set
            {
            }

        }
        public override decimal CalcCost()
            //Precondtions: none
            //Postconditions: the next day air package cost has been returned. 
        {
            const double DIM_VALUE = .40;
            const double WEIGHT_VALUE = .30;
            const double ADD_CHARGE_RATE = .25;
            decimal cost;

            return cost = ((decimal)DIM_VALUE * (decimal)(Length + Width + Height) + (decimal)WEIGHT_VALUE * (decimal)(Weight) + ExpressFee);
            if (IsHeavy() == true)
            {
                return cost + (decimal)(Weight * ADD_CHARGE_RATE);
            }
            else
            {
                if (IsHeavy() == false)
                    return cost;
            }

            if (IsLarge() == true)
            {
                    return cost + (decimal)((Length + Width + Height) * ADD_CHARGE_RATE);
            }
            else
                {
                    if(IsLarge() == false)
                    return cost;
                }
            
        }
        public override string ToString()
            //Precondtions: none
            //Postconditions: returns formatted string with class data
        {
            return string.Format("Next Day Air Package{1}{0}Cost={2:C}{1}", 
                base.ToString(), System.Environment.NewLine, CalcCost());
        }
        }
    

