﻿// Program 1A
// CIS 200
// Due: 5/29/15
// By: AJ McQuillen

// File: TwoDayAir.cs

// The two day air class is a concrete class derived from the Air Package class.
// 2DayAir cost is figured based off Early and Saver properties utilized in the calc cost method 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public class TwoDayAirPackage : AirPackage
    {
        public enum Delivery { EARLY, SAVER };
        //Precondition: None
        //PostCondition: if Saver, customer will save 10% on package. If early, no discount

        public TwoDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height,
            double weight, Delivery deliveryType)
            : base(originAddress, destAddress, length, weight, width, height)
        {
        }
        public Delivery DeliveryType
            //Precondition: None
            //PostCondition: adds deliverytypes Early and Saver
        {
            get;
            set;
        }
        public override decimal CalcCost()
            //Precondition: Early or Saver
            //PostCondition: finds the cost using the formula below and adjusts cost based off Delivery Type
        {
            decimal cost;
            const double ADD_CHARGE_RATE = .25;
            const double DISCOUNT_RATE= .10;

            cost = (decimal)(ADD_CHARGE_RATE*(Length + Width + Height)) + (decimal)(ADD_CHARGE_RATE*(Weight));
            if (DeliveryType == Delivery.SAVER)
                return (cost - (cost * (decimal)DISCOUNT_RATE));
            else
                return cost;
        }
        public override string ToString()
            //Precondition: None
            //PostCondition: returns formatted data
        {
            return string.Format("Two Day Air Package{0}{1}Delivery Type={2}{1}Cost={3}{1}", 
                base.ToString(), Environment.NewLine, DeliveryType, CalcCost());
        }
        }
    
