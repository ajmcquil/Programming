﻿// Program 1A
// CIS 200
// Due: 5/31/15
// By: AJ McQuillen

// File: GroundPackage.cs

// concrete class derived from Package.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    public class GroundPackage : Package
        // Precondtions: zip code is between 00000 and 99999
        // Postconditions: returns specified zone distance and uses it as a factor in the cost method.
    {
        public int zoneDistance;
        public GroundPackage(Address originAddress, Address destAddress, double length, double height, double width,
            double weight)
            : base (originAddress, destAddress, length,width,height,weight)
        {
        }
        public int ZoneDistance
            //Preconditions: zip code properties entered correctly
            //Postconditions: returns zone distance factor
        {
            get
            {
                const int FIRST_DIGIT_FACTOR = 10000;
                int dist;

                dist = Math.Abs((OriginAddress.Zip/FIRST_DIGIT_FACTOR) - (DestinationAddress.Zip/FIRST_DIGIT_FACTOR));
                return dist;
            }
            
        }
        public override decimal CalcCost()
            //Preconditions: zone distance determined
            //Postconditions: returns cost of Ground Package
        {
            const double DIM_FACTOR = .20;
            const double WEIGHT_FACTOR = .05;

            return (decimal)(DIM_FACTOR * (Length + Width + Height) + WEIGHT_FACTOR * (ZoneDistance + 1) * Weight);

        }
        public override string ToString()
            // Preconditions: none
            // Postconditions: returns formatted string from data in class
        {
            return string.Format("Ground Package{1}{0}{1}Zone Distance={2}",
                base.ToString(), Environment.NewLine, ZoneDistance);
        }


        
    }
