﻿// Program 1A
// CIS 200
// Due: 5/31/15
// By: AJ McQuillen

// File: AirPackage.cs

// Abstract class derived from Package. AirPackage is parent class to twodayairpackage and nextdayairpackage
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public abstract class AirPackage : Package
        // Preconditions: size and weight of air package
        // Postconditions: returns AirPackage data and defines if the AirPackage IsHeavy or IsLarge
    {
        protected const int MAX_WEIGHT = 75;
        protected const int MAX_SIZE = 100;
        public AirPackage(Address originAddress, Address destAddress, double length, double weight, double width,
            double height)
            : base(originAddress, destAddress, length, width, height, weight)
        {
        }
        public bool IsHeavy()
            // Preconditions: none
            // Postcondtions: returns true or false based off if the Package IsHeavy (greater than const MAX_WEIGHT)
        {
            if (Weight >= MAX_WEIGHT)
                return true;
            else
                return false;
        }
        public bool IsLarge()
            // Preconditions: none
            // Postconditions: returns true or false based off if the Package IsLarge (greater than const MAX_SIZE)
        {
            if ((Length+Width+Height) >= MAX_SIZE)
                return true;
            else
                return false;
        }
        public override string ToString()
            // Preconditions: none
            // Postconditions: returns formatted string from data in class
        {
            return string.Format("{1}{0}",base.ToString(), Environment.NewLine);
        }
            
    }

