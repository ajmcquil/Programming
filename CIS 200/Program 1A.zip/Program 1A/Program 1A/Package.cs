﻿// Program 1A
// CIS 200
// Due: 5/29/15
// By: AJ MQuillen

// File: Package.cs
// Abstract class that defines the dimensions of all parcels. Serves as Parent class for GroundPackage and AirPackage

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public abstract class Package : Parcel
    {
        // Preconditions: length, width, height, weight all >= 0
        // Postcondition: wil return dimensions in a formatted string
        public double length;
        public double width;
        public double height;
        public double weight;
        public const int MIN_VALUE = 0;
        public Package(Address originAddress, Address destAddress, double length, double width, double height, double weight)
            : base(originAddress, destAddress)
        {
            Length = length;
            Width = width;
            Height = height;
            Weight = weight;
        }
        public double Length
            //Preconditions: Legth>=0
            //Postcondition: return length. if value is negative, throw exception
        {
            get
            {
                return length;
            }
            set
            {
                if (value >= MIN_VALUE)
                    length = value;
                else
                    throw new ArgumentOutOfRangeException("Length", value, "Length must be >= 0");
            }
        }
        public double Width
            // Precondition: Width>=0
            // Postcondition: return width. if negative, throw exception
        {
            get
            {
                return width;
            }
            set
            {
                if (value >= MIN_VALUE)
                    width = value;
                else
                    throw new ArgumentOutOfRangeException("Width", value, "Width must be >= 0");
            }
        }
        public double Height
            // Precondition: Height >= 0
            // Postcondition: return height. if negative, throws exception
        {
            get
            {
                return height;
            }
            set
            {
                if (value >= MIN_VALUE)
                    height = value;
                else
                    throw new ArgumentOutOfRangeException("Height", value, "Height must be >= 0");
            }
        }
        public double Weight
            // Precondition: weight >= 0
            // Postcondition: returns weight. if negative, throws exception
        {
            get
            {
                return weight;
            }
            set
            {
                if (value >= MIN_VALUE)
                    weight = value;
                else
                    throw new ArgumentOutOfRangeException("Weight", value, "Weight must be >= 0");
            }
        }
        public override string ToString()
            // Precondition: none
            // Postcondition: returns formatted string with class data
        {
            return string.Format("Package{0}{1}Length={2}{1}Width={3}{1}Height={4}{1}Weight={5}",
                base.ToString(), Environment.NewLine, Length, Width, Height, Weight);
        }


    }

