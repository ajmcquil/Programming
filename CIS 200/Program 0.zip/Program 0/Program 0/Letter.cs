﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    class Letter : Parcel//derived class letter from parcel
    {
        private decimal fixedCost;//fixed cost
        private const int MIN_VALUE = 0;//constant to eliminate magic numbers
        //Letter constructor utilizing base class properties and setting constructor for fixed cost
        public Letter(Address origin, Address destination, decimal cost) :base(origin, destination)
        {
            fixedCost = cost;
        }
        private decimal FixedCost//constructor definition so fixed cost returns input value, but validates to be greater than 0
        {
            get
            {
                return fixedCost;
            }
            set
            {
                if (value > MIN_VALUE)
                    fixedCost = value;
                else
                    throw new ArgumentOutOfRangeException(
                        "FixedCost", value, "Fixed Cost must be greater than 0");//same exception argument from address
            }
        }
        //Preconditions: None
        //Postconditions: returns the cost of the parcel
        public override decimal CalcCost()//overrides calcost to just display fixed cost 
        {
            return fixedCost;
        }
        public override string ToString()//string format for calc cost. base.ToString calls inherited formatting from parcel
        {
            return string.Format("\n{0}\nCost= {1:C}", base.ToString(), FixedCost);
        }
        }
    }

