﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public abstract class Parcel//abstract public class Parcel, the parent class to Letter
    {
        public Address OriginAddress { get; set; }//uses the Address class to build new constructor in Parcel
        public Address DestinationAddress { get; set; }

        public Parcel(Address origin, Address destination)//constructor in Parcel that will define originAddress and destiantionAddress
        {
            OriginAddress = origin;
            DestinationAddress = destination;
        }
        //Precondition: No
        //PostCondition: returns the cost of the parcel
        public abstract decimal  CalcCost();//abstract calc cost method
        //Preccondition:
        public override string ToString()//string format for how origin address and destination address will be displayed
        {
            return string.Format("Origin Address\n---------------{0}\nDestination Address\n--------------------{1}", 
                OriginAddress,DestinationAddress);
        }
    }
}