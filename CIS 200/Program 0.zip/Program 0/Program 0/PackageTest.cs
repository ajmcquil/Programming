﻿//AJ McQuillen
//CIS 200-01
//May 21, 2015
//Program 0- the purpose of this program is to use composition and inheritance (HAS-A, IS-A) relationships to 
//lay the groundwork for future programs. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    class Program
    {
        static void Main(string[] args)
        {
            //Lists 4 addresses and assigns them as properties for 3 letters
            Address address1 = new Address("Broadway Joe","100 East Broadway","","New York","NY",10010);
            Address address2 = new Address("Adam West","200 West Liberty","","Seattle","WA",98101);
            Address address3 = new Address("Kobe Bryant", "300 West Main","","Los Angeles","CA",90001);
            Address address4 = new Address("Dick Butkus","400 East Jefferson","","Chicago","IL",60290);
            Letter firstLetter = new Letter(address1, address2, 100);
            Letter secondLetter = new Letter( address2, address3,150);
            Letter thirdLetter = new Letter(address3, address4, 200);
            
            //Create Parcel List and Add letters to Parcel List
            List<Parcel> items = new List<Parcel>();
            items.Add(firstLetter);
            items.Add(secondLetter);
            items.Add(thirdLetter);
            
            //Print the letter information with formatted headers
            Console.WriteLine("\n**Letter 1**\n{0}", firstLetter);
            Console.WriteLine("\n**Letter 2**\n{0}", secondLetter);
            Console.WriteLine("\n**Letter 3**\n{0}", thirdLetter);
        }
    }
}
