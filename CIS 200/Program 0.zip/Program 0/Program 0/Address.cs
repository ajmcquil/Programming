﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public class Address//Address class
    {
        public string Name { get; private set; }//get and set properties default for Name
        public string Address1 { get; private set; }//get and set properties default for Address1
        public string Address2 { get; private set; }//get and set properties default for Address2
        public string City { get; private set; }//get and set properties default for city
        public string State { get; private set; }//get and set properties default for state
        public int zip;//no deafault for zip since it will have conditions
        public const int MIN_ZIP = 0;//constants to eliminate the need for magic numbers
        public const int MAX_ZIP = 99999;//constant to eliminate the need for magic numbers

        public Address( string theName, string theAddress1, string theAddress2,string theCity,
            string theState, int theZip)//constructor to initialize name, addresses, city, state, and zip
        {
            Name = theName;
            Address1 = theAddress1;
            Address2 = theAddress2;
            City = theCity;
            State = theState;
            zip = theZip;
        }
        public int Zip//sets conditions for Zip, less than 99999 but greater than 0
        {
            get
            {
                return zip;
            }
            private set
            {
                if (value > MIN_ZIP && value <= MAX_ZIP)
                    zip = value;
                else
                    throw new ArgumentOutOfRangeException(
                        "Zip", value, "Zip must be between 0 and 99999");//exception argument if the number does not meet this criteria
            }
        }
            public override string ToString()//formatted string to structure name, address, city, state, zip output
            {
                return string.Format( "\n{0}\n{1}\n{2}{3},{4} {5:D5}\n",Name, Address1, Address2, 
                    City, State, Zip);
            }
        }
    }