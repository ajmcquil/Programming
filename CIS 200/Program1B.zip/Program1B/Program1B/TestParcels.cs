﻿// Program 1B
// CIS 200
// Due: 6/3/15
// By: AJ McQuillen & Andrew Wright
// this program (specifically this class) explores the use of LINQ to sort and display lists. We used classes, methods,
// properties, and lists developed in Program 0 and 1A. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class TestParcels
    {
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            //Precondition: none
            //Postcondition: list of 8 addresses witha list of parcels
            Address a1 = new Address("John Smith", "123 Any St.", "Apt. 45",
                "Louisville", "KY", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.", "",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 14101); // Test Address 4
            Address a5 = new Address("Bob Dole", "456 Viagra Lane", "",
                "Russell", "KS", 67665);
            Address a6 = new Address("Sheldon Cooper", "2300 Los Robles Road", "Apr. 4A",
                "Pasadena", "CA", 90041);
            Address a7 = new Address("Danny Tanner", "1709 Broderick Street", "",
                "San Francisco", "CA", 94115);
            Address a8 = new Address("Rachel Green", "90 Bedford St.", "Apt. 20",
                "New York", "NY", 10014);

            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            Letter letter2 = new Letter(a3, a6, 4.89M);
            GroundPackage gp1 = new GroundPackage(a6, a4, 14, 10, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a8, a7, 22, 58, 9, 75.8);
            NextDayAirPackage ndap1 = new NextDayAirPackage(a2, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a4, a5, 9, 8, 11, 
                74.9, 5.30M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a5, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a7, a8, 19.3, 22.5, 4.9,
                79.5, TwoDayAirPackage.Delivery.Early);

            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>(); 
            
            //add test data to list
            parcels.Add(letter1);
            parcels.Add(letter2);
            parcels.Add(gp1);
            parcels.Add(gp2);
            parcels.Add(ndap1);
            parcels.Add(ndap2);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
           
            // Part A
            // Selects all parcels and orders them in descending order by their zip code.
            // Then prints a formatted string to the console displaying the destination name and the zip
            var selectAllParcelsDestZip =
                from par in parcels
                orderby par.DestinationAddress.Zip descending
                select new { par.DestinationAddress.Name, par.DestinationAddress.Zip };
            Console.WriteLine("A) Parcels Sorted by Destination Address Zip\n");
            Console.WriteLine("ZipCode descending");
            Console.WriteLine("-------------------\n");
            foreach (var p in selectAllParcelsDestZip)
                Console.WriteLine("{0} = {1}", p.Name, p.Zip);
            Console.WriteLine("\n");
            
            // Part B
            // selects all parcels then sorts them by cost from least expensive to most
            // Prints a formatted string to the console displaying the origin name and the cost of each package
            var selectAllParcelsCost =
                from par in parcels
                let cost = par.CalcCost()
                orderby cost
                select new { cost = par.CalcCost(), par.OriginAddress.Name };
            Console.WriteLine("B) Parcels Sorted by Cost\n");
            Console.WriteLine("Cost Ascending");
            Console.WriteLine("----------------\n");
            foreach (var p in selectAllParcelsCost)
                Console.WriteLine("{1} = {0:C}", p.cost, p.Name);
            Console.WriteLine("\n");

            // Part C
            // selects all parcels by their type using the GetType() method
            // Sorts and prints the types in ascending order by their type
            var selectAllParcelsByType =
                from par in parcels
                let type = par.GetType().ToString()
                orderby type
                select new {type = par.GetType().ToString()};
            Console.WriteLine("C) Parcels Sorted by Parcel Type\n");
            Console.WriteLine("Type Ascending");
            Console.WriteLine("---------------\n");
            foreach (var p in selectAllParcelsByType)
                Console.WriteLine("{0}",p.type);
            Console.WriteLine("\n");
            //selects all parcels by their type using the GetType method
            //sorts and prints the type ordered by the cost of each parcel in descending order
            var orderTypeByCost =
                from par in parcels
                let type = par.GetType().ToString()
                let cost = par.CalcCost()
                orderby cost descending
                select new { type = par.GetType().ToString(), cost };
            Console.WriteLine("Cost descending");
            Console.WriteLine("----------------\n");
            foreach (var p in orderTypeByCost)
                Console.WriteLine("{0} = {1:C}", p.type, p.cost);
            Console.WriteLine("\n");

            // Part D
            // selects all heavy packages from the list
            // sorts and prints the heavy packages by weight and lists by type
            var selectHeavyAirPackage =
                from par in parcels
                where par is AirPackage
                let AP = par as AirPackage
                let weight = AP.Weight
                let type = par.GetType().ToString()
                where AP.IsHeavy() == true
                orderby weight descending
                select new {AP = AP.IsHeavy(), weight, type };
            Console.WriteLine("D) Air Packages that are Heavy sorted by weight\n");
            Console.WriteLine("Weight Descending");
            Console.WriteLine("------------------\n");
            foreach (var p in selectHeavyAirPackage)
                Console.WriteLine("{0} = {1}",p.type, p.weight );
            Console.WriteLine();
                
       }

        //// Precondition:  None
        //// Postcondition: Pauses program execution until user presses Enter and
        ////                then clears the screen
        public static void Pause()
        {
            Console.WriteLine("Press Enter to Continue...");
            Console.ReadLine();

            Console.Clear(); // Clear screen
        }
    }
        
    

