﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Andrew McQuillen 
//CIS199-01 
//February 16, 2015 
//Program 1 Paint cost analyzer
namespace Program1
{
    public partial class Program1 : Form
    {
        public Program1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // declarations
            decimal squareFoot;                 
            decimal coatsOfPaint;               
            decimal priceOfPaint;               
            decimal totalSquareFoot;                   
            decimal totalGallons;               
            decimal totalLabor;                 
            const decimal HOUR_RATE = 10.5m;    
            decimal totalCostLabor;             
            decimal totalCostPaint;             
            decimal totalCost;                  
            const decimal SQFT_FACTOR = 325;    
            const decimal HRS_PER = 8;          

            // gathers user input from form
            squareFoot = decimal.Parse(sqftTextBox.Text); 
            priceOfPaint = decimal.Parse(pricePerGallonTextBox.Text);
            coatsOfPaint = decimal.Parse(coatsOfPaintTextBox.Text);

           //performs calculations and defines display parameters
            totalSquareFoot = squareFoot * coatsOfPaint;
            sqftDisplay.Text = totalSquareFoot.ToString("n1");
            totalGallons = Math.Ceiling(totalSquareFoot / SQFT_FACTOR);
            gallonsDisplay.Text = totalGallons.ToString("n0");
            totalLabor = totalSquareFoot / SQFT_FACTOR * HRS_PER;
            laborDisplay.Text = totalLabor.ToString("n1");
            totalCostPaint = priceOfPaint * totalGallons;
            totalCostOfPaintDisplay.Text = totalCostPaint.ToString("c");
            totalCostLabor = totalLabor * HOUR_RATE;
            totalCostOfLaborDisplay.Text = totalCostLabor.ToString("c");
            totalCost = totalCostLabor + totalCostPaint;
            totalCostDisplay.Text = totalCost.ToString("c");
        }
    }
}
