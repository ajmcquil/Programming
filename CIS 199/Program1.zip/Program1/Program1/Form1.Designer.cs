﻿namespace Program1
{
    partial class Program1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Program1));
            this.sqftLabel = new System.Windows.Forms.Label();
            this.gallonPrice = new System.Windows.Forms.Label();
            this.paintCoatsLabel = new System.Windows.Forms.Label();
            this.sqftTextBox = new System.Windows.Forms.TextBox();
            this.pricePerGallonTextBox = new System.Windows.Forms.TextBox();
            this.coatsOfPaintTextBox = new System.Windows.Forms.TextBox();
            this.sqftDisplay = new System.Windows.Forms.Label();
            this.laborDisplay = new System.Windows.Forms.Label();
            this.gallonsDisplay = new System.Windows.Forms.Label();
            this.totalSqftLabel = new System.Windows.Forms.Label();
            this.hrsLaborLabel = new System.Windows.Forms.Label();
            this.totalGallonsLabel = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.totalCostOfPaintDisplay = new System.Windows.Forms.Label();
            this.totalCostOfLaborDisplay = new System.Windows.Forms.Label();
            this.totalCostDisplay = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.SuspendLayout();
            // 
            // sqftLabel
            // 
            this.sqftLabel.AutoSize = true;
            this.sqftLabel.Location = new System.Drawing.Point(182, 14);
            this.sqftLabel.Name = "sqftLabel";
            this.sqftLabel.Size = new System.Drawing.Size(65, 13);
            this.sqftLabel.TabIndex = 0;
            this.sqftLabel.Text = "Square Foot";
            // 
            // gallonPrice
            // 
            this.gallonPrice.AutoSize = true;
            this.gallonPrice.Location = new System.Drawing.Point(122, 82);
            this.gallonPrice.Name = "gallonPrice";
            this.gallonPrice.Size = new System.Drawing.Size(125, 13);
            this.gallonPrice.TabIndex = 1;
            this.gallonPrice.Text = "Price of Paint (per gallon)";
            // 
            // paintCoatsLabel
            // 
            this.paintCoatsLabel.AutoSize = true;
            this.paintCoatsLabel.Location = new System.Drawing.Point(133, 47);
            this.paintCoatsLabel.Name = "paintCoatsLabel";
            this.paintCoatsLabel.Size = new System.Drawing.Size(114, 13);
            this.paintCoatsLabel.TabIndex = 2;
            this.paintCoatsLabel.Text = "Coats of Paint Needed";
            // 
            // sqftTextBox
            // 
            this.sqftTextBox.Location = new System.Drawing.Point(257, 11);
            this.sqftTextBox.Name = "sqftTextBox";
            this.sqftTextBox.Size = new System.Drawing.Size(100, 20);
            this.sqftTextBox.TabIndex = 1;
            // 
            // pricePerGallonTextBox
            // 
            this.pricePerGallonTextBox.Location = new System.Drawing.Point(257, 79);
            this.pricePerGallonTextBox.Name = "pricePerGallonTextBox";
            this.pricePerGallonTextBox.Size = new System.Drawing.Size(100, 20);
            this.pricePerGallonTextBox.TabIndex = 3;
            // 
            // coatsOfPaintTextBox
            // 
            this.coatsOfPaintTextBox.Location = new System.Drawing.Point(257, 45);
            this.coatsOfPaintTextBox.Name = "coatsOfPaintTextBox";
            this.coatsOfPaintTextBox.Size = new System.Drawing.Size(100, 20);
            this.coatsOfPaintTextBox.TabIndex = 2;
            // 
            // sqftDisplay
            // 
            this.sqftDisplay.BackColor = System.Drawing.SystemColors.ControlLight;
            this.sqftDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sqftDisplay.Location = new System.Drawing.Point(55, 155);
            this.sqftDisplay.Name = "sqftDisplay";
            this.sqftDisplay.Size = new System.Drawing.Size(80, 20);
            this.sqftDisplay.TabIndex = 6;
            this.sqftDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // laborDisplay
            // 
            this.laborDisplay.BackColor = System.Drawing.SystemColors.ControlLight;
            this.laborDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.laborDisplay.Location = new System.Drawing.Point(336, 155);
            this.laborDisplay.Name = "laborDisplay";
            this.laborDisplay.Size = new System.Drawing.Size(80, 20);
            this.laborDisplay.TabIndex = 7;
            this.laborDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gallonsDisplay
            // 
            this.gallonsDisplay.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gallonsDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsDisplay.Location = new System.Drawing.Point(192, 155);
            this.gallonsDisplay.Name = "gallonsDisplay";
            this.gallonsDisplay.Size = new System.Drawing.Size(80, 20);
            this.gallonsDisplay.TabIndex = 8;
            this.gallonsDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalSqftLabel
            // 
            this.totalSqftLabel.AutoSize = true;
            this.totalSqftLabel.Location = new System.Drawing.Point(40, 133);
            this.totalSqftLabel.Name = "totalSqftLabel";
            this.totalSqftLabel.Size = new System.Drawing.Size(110, 13);
            this.totalSqftLabel.TabIndex = 9;
            this.totalSqftLabel.Text = "Total Square Footage";
            // 
            // hrsLaborLabel
            // 
            this.hrsLaborLabel.AutoSize = true;
            this.hrsLaborLabel.Location = new System.Drawing.Point(315, 133);
            this.hrsLaborLabel.Name = "hrsLaborLabel";
            this.hrsLaborLabel.Size = new System.Drawing.Size(123, 13);
            this.hrsLaborLabel.TabIndex = 10;
            this.hrsLaborLabel.Text = "Hours of Labor Required";
            // 
            // totalGallonsLabel
            // 
            this.totalGallonsLabel.AutoSize = true;
            this.totalGallonsLabel.Location = new System.Drawing.Point(172, 133);
            this.totalGallonsLabel.Name = "totalGallonsLabel";
            this.totalGallonsLabel.Size = new System.Drawing.Size(121, 13);
            this.totalGallonsLabel.TabIndex = 11;
            this.totalGallonsLabel.Text = "Total Number of Gallons";
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.AutoSize = true;
            this.paintCostLabel.Location = new System.Drawing.Point(49, 194);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(94, 13);
            this.paintCostLabel.TabIndex = 12;
            this.paintCostLabel.Text = "Total Cost of Paint";
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.Location = new System.Drawing.Point(88, 269);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(55, 13);
            this.totalCostLabel.TabIndex = 13;
            this.totalCostLabel.Text = "Total Cost";
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.AutoSize = true;
            this.laborCostLabel.Location = new System.Drawing.Point(46, 225);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(97, 13);
            this.laborCostLabel.TabIndex = 14;
            this.laborCostLabel.Text = "Total Cost of Labor";
            // 
            // totalCostOfPaintDisplay
            // 
            this.totalCostOfPaintDisplay.BackColor = System.Drawing.SystemColors.ControlLight;
            this.totalCostOfPaintDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostOfPaintDisplay.Location = new System.Drawing.Point(158, 190);
            this.totalCostOfPaintDisplay.Name = "totalCostOfPaintDisplay";
            this.totalCostOfPaintDisplay.Size = new System.Drawing.Size(80, 20);
            this.totalCostOfPaintDisplay.TabIndex = 15;
            this.totalCostOfPaintDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalCostOfLaborDisplay
            // 
            this.totalCostOfLaborDisplay.BackColor = System.Drawing.SystemColors.ControlLight;
            this.totalCostOfLaborDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostOfLaborDisplay.Location = new System.Drawing.Point(158, 221);
            this.totalCostOfLaborDisplay.Name = "totalCostOfLaborDisplay";
            this.totalCostOfLaborDisplay.Size = new System.Drawing.Size(80, 20);
            this.totalCostOfLaborDisplay.TabIndex = 16;
            this.totalCostOfLaborDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalCostDisplay
            // 
            this.totalCostDisplay.BackColor = System.Drawing.SystemColors.ControlLight;
            this.totalCostDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalCostDisplay.Location = new System.Drawing.Point(158, 265);
            this.totalCostDisplay.Name = "totalCostDisplay";
            this.totalCostDisplay.Size = new System.Drawing.Size(80, 20);
            this.totalCostDisplay.TabIndex = 17;
            this.totalCostDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            this.calculateButton.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.calculateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.calculateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateButton.ForeColor = System.Drawing.SystemColors.WindowText;
            this.calculateButton.Image = ((System.Drawing.Image)(resources.GetObject("calculateButton.Image")));
            this.calculateButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.calculateButton.Location = new System.Drawing.Point(318, 194);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(120, 94);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.calculateButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.calculateButton.UseVisualStyleBackColor = false;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(478, 320);
            this.shapeContainer1.TabIndex = 18;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 42;
            this.lineShape1.X2 = 240;
            this.lineShape1.Y1 = 247;
            this.lineShape1.Y2 = 247;
            // 
            // Program1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(478, 320);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalCostDisplay);
            this.Controls.Add(this.totalCostOfLaborDisplay);
            this.Controls.Add(this.totalCostOfPaintDisplay);
            this.Controls.Add(this.laborCostLabel);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.paintCostLabel);
            this.Controls.Add(this.totalGallonsLabel);
            this.Controls.Add(this.hrsLaborLabel);
            this.Controls.Add(this.totalSqftLabel);
            this.Controls.Add(this.gallonsDisplay);
            this.Controls.Add(this.laborDisplay);
            this.Controls.Add(this.sqftDisplay);
            this.Controls.Add(this.coatsOfPaintTextBox);
            this.Controls.Add(this.pricePerGallonTextBox);
            this.Controls.Add(this.sqftTextBox);
            this.Controls.Add(this.paintCoatsLabel);
            this.Controls.Add(this.gallonPrice);
            this.Controls.Add(this.sqftLabel);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "Program1";
            this.Text = "Program1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sqftLabel;
        private System.Windows.Forms.Label gallonPrice;
        private System.Windows.Forms.Label paintCoatsLabel;
        private System.Windows.Forms.TextBox sqftTextBox;
        private System.Windows.Forms.TextBox pricePerGallonTextBox;
        private System.Windows.Forms.TextBox coatsOfPaintTextBox;
        private System.Windows.Forms.Label sqftDisplay;
        private System.Windows.Forms.Label laborDisplay;
        private System.Windows.Forms.Label gallonsDisplay;
        private System.Windows.Forms.Label totalSqftLabel;
        private System.Windows.Forms.Label hrsLaborLabel;
        private System.Windows.Forms.Label totalGallonsLabel;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label totalCostOfPaintDisplay;
        private System.Windows.Forms.Label totalCostOfLaborDisplay;
        private System.Windows.Forms.Label totalCostDisplay;
        private System.Windows.Forms.Button calculateButton;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
    }
}

