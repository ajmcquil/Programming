﻿// Andrew McQuillen
// CIS 199-01
// April 26, 2015
// Program 4-- This program is a simple package cost calculator for Ground Packages. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_4
{
    public partial class Program4 : Form
    {
        // placeholder for the package listbox
        private List<GroundPackage> packageList = new List<GroundPackage>();
        // named constants and variables
        int originZip;
        int destinationZip;
        double length;
        double width;
        double height;
        double weight;
        int zoneDistance;
        const int ZIP_LENGTH = 4;
        const int UOFL_ZIP = 40292;
        public Program4()
        {
            InitializeComponent();
        }
        // add button checks if values input in field are appropriate and collects them if they are and puts them in
        // the calc cost method created in the GroundPackage class. 
        private void addButton_Click(object sender, EventArgs e)
        {
            // parses all texboxes
            if ((int.TryParse(originBox.Text, out originZip) && int.TryParse(destinationBox.Text, out destinationZip) && double.TryParse(lengthBox.Text, out length) &&
                double.TryParse(widthBox.Text, out width) && double.TryParse(heightBox.Text, out height) && double.TryParse(weightBox.Text, out weight)))
            {
                // all constraints for parsed values
                if (originZip.ToString().Length == ZIP_LENGTH)
                {
                    MessageBox.Show("Enter A Valid Zip Code!");
                    return;
                }
                if (destinationZip.ToString().Length == ZIP_LENGTH)
                {
                    MessageBox.Show("Enter A Valid Zip Code!");
                    return;
                }
                if (length <= 0 || width <= 0 || height <= 0 || weight <= 0)
                {
                    MessageBox.Show("Enter A Positive Number!");
                    return;
                }
            
                // assuming values are correct, we store values in the GroundPackage class to be recalled for calculations, lists
                // and details boxes.
                GroundPackage myPackage = new GroundPackage(originZip, destinationZip, length, width, height, weight);
                myPackage.OriginZip = originZip;
                myPackage.DestinationZip = destinationZip;
                myPackage.Length = length;
                myPackage.Width = width;
                myPackage.Weight = weight;
                myPackage.Height = height;
                packageList.Add(myPackage);
                // used convert.tostring to convert type int to type string on origin and destination zip 
                // this was done to take the first number of each zip code for the zoneDistance calculation.
                int i = originZip;
                int first = Convert.ToInt32(i.ToString().Substring(0,1));
                int j = destinationZip;
                int primary = Convert.ToInt32(j.ToString().Substring(0,1));
                // the zone distance calculation takes the absolute value of the difference
                // of origin and destination zip in order to avoid negative numbers.
                zoneDistance = Math.Abs(first - primary);
                // calls the calccost method. once its calculated it is stored in the listbox
                packageListBox.Items.Add(myPackage.CalcCost(length, width, height, zoneDistance, weight).ToString("c"));
            }
            // enusres no field is left blank
            else
            {
                MessageBox.Show("Enter Numeric Data In Each Field!");
            }
            }
        // details button shows package details of selected index. the format is done in the GroundPackage Class
        // using the ToString over ride method and environment.newline
        private void detailsButton_Click(object sender, EventArgs e)
        {
            int index = packageListBox.SelectedIndex;
            if (index != -1)
            {
                MessageBox.Show(packageList[index].ToString(), Environment.NewLine);
            }

            else
            {
                MessageBox.Show("Please Select a Price from the List Box!");
            }
    }
        // from button does everythig the add button does, but changes the origin zip to UofL's zip
        private void fromButton_Click(object sender, EventArgs e)
        {
            
            int newOriginZip = UOFL_ZIP; // instead of parsing, I set the origin zip to named const UOFL_ZIP and finds the new price
            if (int.TryParse(destinationBox.Text, out destinationZip) && double.TryParse(lengthBox.Text, out length) &&
                double.TryParse(widthBox.Text, out width) && double.TryParse(heightBox.Text, out height) && double.TryParse(weightBox.Text, out weight))
            {
                GroundPackage myPackage = new GroundPackage(newOriginZip, destinationZip, length, width, height, weight);

                myPackage.OriginZip = newOriginZip;
                myPackage.DestinationZip = destinationZip;
                myPackage.Length = length;
                myPackage.Width = width;
                myPackage.Weight = weight;
                myPackage.Height = height;
                packageList.Add(myPackage);
            }
            // used the name newOriginZip above and below in place of originZip
            int i = newOriginZip;
            int one = Convert.ToInt32(i.ToString().Substring(0, 1));
            int j = destinationZip;
            int onetoo = Convert.ToInt32(j.ToString().Substring(0, 1));
            zoneDistance = Math.Abs(one - onetoo);

            int index = packageListBox.SelectedIndex;
            if (index != -1)
            {
                // This updates the messagebox to show the newOriginZip instead of entered origin zip
                packageList[index].OriginZip = newOriginZip;
                packageListBox.Items[index] = packageList[index].CalcCost(length, width, height, zoneDistance, weight).ToString("c");
                MessageBox.Show(packageListBox.Items[index].ToString());
                MessageBox.Show(packageList[index].ToString(), Environment.NewLine);
            }
            else
            {
                MessageBox.Show("Please Select a Price from the List Box!");
            }
        }
        // To uofl button takes the destination zip and changes it to uofls address and finds the price.
        private void toButton_Click(object sender, EventArgs e)
        {
            int newDestinationZip = UOFL_ZIP;
            if (int.TryParse(originBox.Text, out originZip) && double.TryParse(lengthBox.Text, out length) &&
                double.TryParse(widthBox.Text, out width) && double.TryParse(heightBox.Text, out height) && double.TryParse(weightBox.Text, out weight))
            {
                GroundPackage myPackage = new GroundPackage(originZip, newDestinationZip, length, width, height, weight);

                myPackage.OriginZip = originZip;
                myPackage.DestinationZip = newDestinationZip; // new destination zip replaces destinationZip
                myPackage.Length = length;
                myPackage.Width = width;
                myPackage.Weight = weight;
                myPackage.Height = height;
                packageList.Add(myPackage);
            }

            int i = newDestinationZip;
            int one = Convert.ToInt32(i.ToString().Substring(0, 1));
            int j = destinationZip;
            int onetoo = Convert.ToInt32(j.ToString().Substring(0, 1));
            zoneDistance = Math.Abs(one - onetoo);

            int index = packageListBox.SelectedIndex;
            if (index != -1)
            {
                packageList[index].DestinationZip = newDestinationZip;
                packageListBox.Items[index] = packageList[index].CalcCost(length, width, height, zoneDistance, weight).ToString("c");
                MessageBox.Show(packageListBox.Items[index].ToString());
                MessageBox.Show(packageList[index].ToString(), Environment.NewLine);
            }
            else
            {
                MessageBox.Show("Please Select a Price from the List Box!");
            }
        }

        }                                 
        }
    



