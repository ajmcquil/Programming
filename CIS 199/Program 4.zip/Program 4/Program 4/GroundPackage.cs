﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    public class GroundPackage
    {
        // named constants and variables
        public const double FIRST_VALUE = .20;
        public const double SECOND_VALUE = .50;
        public const int MIN_ZIP = 00000;
        public const int MAX_ZIP = 99999;
        private int _originZip;
        private int _destinationZip;
        private double _length;
        private double _width;
        private double _height;
        private double _weight;
        private int _zoneDistance;

        public GroundPackage(int oz, int dz, double l, double w, double h, double lb)
        {
            OriginZip = oz;
            DestinationZip = dz;
            Length = l;
            Width = w;
            Height = h;
            Weight = lb;
        } 
        public int OriginZip //origin preconditions between 00000 and 99999 are handled here
        {
            get {return _originZip;}
            set
            {
                if ((value >= MIN_ZIP) && (value <= MAX_ZIP))
                    _originZip = value;
            }
        }
        public int DestinationZip// destination zip preconditions of 00000 and 99999 are handled here
        {
            get {return _destinationZip;}
            set
            {
                if ((value >= MIN_ZIP) && (value <= MAX_ZIP))
                    _destinationZip = value;
            }
        }
        public double Length// handles length preconditions of > 0
        {
            get {return _length;}
            set
            {
                if (value > 0)
                    _length = value;
            }
        }
        public double Width // handles width preconditions of > 0
        {
            get { return _width;}
            set
            {
                if (value > 0)
                    _width = value;
            }
        }
        public double Height// handles height preconditions of > 0
        {
            get {return _height;}
            set
            {
                if (value > 0)
                    _height = value;
            }
        }
        public double Weight// handles weight preconditions of > 0
        {
            get {return _weight;}
            set
            {
                if (value > 0)
                    _weight = value;
            }

        }
        public int ZoneDistance// returns zonedistance which is calculated in the form
        {
            get { return _zoneDistance; }
            

        }
        // calc cost method performs cost of package calculations. constants first value and second value are used
        // instead of raw numbers. 
        public double CalcCost(double Length, double Width, double Height, int ZoneDistance, double Weight)
        {
               return  (FIRST_VALUE * (Length + Width + Height) + SECOND_VALUE * (ZoneDistance + 1) * (Weight));
        }
        // over ride ToSTring sets the format for how messagebox details will be displayed when calling the ToString method.
        public override string ToString()
        {
            return ("Origin Zip: " + OriginZip.ToString() + Environment.NewLine + "Destination Zip: " + DestinationZip.ToString() + Environment.NewLine + "Length: " + Length.ToString() + Environment.NewLine + "Width: " + Width.ToString() + Environment.NewLine + "Height: " + Height.ToString() + Environment.NewLine + "Weight: " + Weight.ToString());
        }
    }
}
