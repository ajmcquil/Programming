﻿//Andrew McQuillen CIS 199-01 Program 2 Registration March 9, 2015
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class program2 : Form
    {
        public program2()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            char firstLetter;                                   //declaration
            firstLetter = char.Parse(lastNameBox.Text);
            string day1 = "April 1st";
            string day2 = "April 2nd";
            string day3 = "April 3rd";
            string day4 = "April 6th";
            string day5 = "April 7th";
            string day6 = "April 8th";
            string time1 = "8:30am";
            string time2 = "10:00am";
            string time3 = "11:30am";
            string time4 = "2:00pm";
            string time5 = "4:00pm";
            
            if (char.IsLower(firstLetter))                      //Shows error message if lower case
                    {
                        MessageBox.Show("Input First Letter of Last Name In Caps");
                    }
                    if (srRadio.Checked)                        //Senior Class registration logic
                    {
                        if (firstLetter <= 'D')
                            MessageBox.Show("You may register on " + day1 + " at " + time2);
                        else if (firstLetter <= 'I')
                            MessageBox.Show("You may register on " + day1 + " at " + time3);
                        else if (firstLetter <= 'O')
                            MessageBox.Show("You may register on " + day1 + " at " + time4);
                        else if (firstLetter <= 'S')
                            MessageBox.Show("You may register on " + day1 + " at " + time5);
                        else if (firstLetter <= 'Z')
                            MessageBox.Show("You may register on " + day1 + " at " + time1);
                    }
                    if (jrRadio.Checked)                        //Junior Class registration logic
                    {
                        if (firstLetter <= 'D')
                            MessageBox.Show("You may register on " + day2 + " at " + time2);
                        else if (firstLetter <= 'I')
                            MessageBox.Show("You may register on " + day2 + " at " + time3);
                        else if (firstLetter <= 'O')
                            MessageBox.Show("You may register on " + day2 + " at " + time4);
                        else if (firstLetter <= 'S')
                            MessageBox.Show("You may register on " + day2 + " at " + time5);
                        else if (firstLetter <= 'Z')
                            MessageBox.Show("You may register on " + day2 + " at " + time5);
                    }
                    if (sophRadio.Checked)                      //Sophomore Class registration logic
                    {
                        if (firstLetter <= 'B')
                            MessageBox.Show("You may register on " + day3 + " at " + time3);
                        else if (firstLetter <= 'D')
                            MessageBox.Show("You may register on " + day3 + " at " + time4);
                        else if (firstLetter <= 'F')
                            MessageBox.Show("You may register on " + day3 + " at " + time5);
                        else if (firstLetter <= 'I')
                            MessageBox.Show("You may register on " + day4 + " at " + time1);
                        else if (firstLetter <= 'L')
                            MessageBox.Show("You may register on " + day4 + " at " + time2);
                        else if (firstLetter <= 'O')
                            MessageBox.Show("You may register on " + day4 + " at " + time3);
                        else if (firstLetter <= 'Q')
                            MessageBox.Show("You may register on " + day4 + " at " + time4);
                        else if (firstLetter <= 'S')
                            MessageBox.Show("You may register on " + day4 + " at " + time5);
                        else if (firstLetter <= 'V')
                            MessageBox.Show("You may register on " + day3 + " at " + time1);
                        else if (firstLetter <= 'Z')
                            MessageBox.Show("You may register on " + day3 + " at " + time2);
                    }
                    if (freshRadio.Checked)                     //Freshman Class registration logic
                    {
                        if (firstLetter <= 'B')
                            MessageBox.Show("You may register on " + day5 + " at " + time3);
                        else if (firstLetter <= 'D')
                            MessageBox.Show("You may register on " + day5 + " at " + time4);
                        else if (firstLetter <= 'F')
                            MessageBox.Show("You may register on " + day5 + " at " + time5);
                        else if (firstLetter <= 'I')
                            MessageBox.Show("You may register on " + day6 + " at " + time1);
                        else if (firstLetter <= 'L')
                            MessageBox.Show("You may register on " + day6 + " at " + time2);
                        else if (firstLetter <= 'O')
                            MessageBox.Show("You may register on " + day6 + " at " + time3);
                        else if (firstLetter <= 'Q')
                            MessageBox.Show("You may register on " + day6 + " at " + time4);
                        else if (firstLetter <= 'S')
                            MessageBox.Show("You may register on " + day6 + " at " + time5);
                        else if (firstLetter <= 'V')
                            MessageBox.Show("You may register on " + day5 + " at " + time1);
                        else if (firstLetter <= 'Z')
                            MessageBox.Show("You may register on " + day5 + " at " + time2);
                    }
                }
                
            }

        }
    

