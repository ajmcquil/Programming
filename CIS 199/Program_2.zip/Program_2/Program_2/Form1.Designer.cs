﻿namespace Program_2
{
    partial class program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.classGroupBox = new System.Windows.Forms.GroupBox();
            this.srRadio = new System.Windows.Forms.RadioButton();
            this.jrRadio = new System.Windows.Forms.RadioButton();
            this.sophRadio = new System.Windows.Forms.RadioButton();
            this.freshRadio = new System.Windows.Forms.RadioButton();
            this.lastNameBox = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.classGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // classGroupBox
            // 
            this.classGroupBox.Controls.Add(this.srRadio);
            this.classGroupBox.Controls.Add(this.jrRadio);
            this.classGroupBox.Controls.Add(this.sophRadio);
            this.classGroupBox.Controls.Add(this.freshRadio);
            this.classGroupBox.Location = new System.Drawing.Point(42, 25);
            this.classGroupBox.Name = "classGroupBox";
            this.classGroupBox.Size = new System.Drawing.Size(200, 112);
            this.classGroupBox.TabIndex = 0;
            this.classGroupBox.TabStop = false;
            this.classGroupBox.Text = "Current Academic Class";
            // 
            // srRadio
            // 
            this.srRadio.AutoSize = true;
            this.srRadio.Location = new System.Drawing.Point(61, 89);
            this.srRadio.Name = "srRadio";
            this.srRadio.Size = new System.Drawing.Size(55, 17);
            this.srRadio.TabIndex = 3;
            this.srRadio.TabStop = true;
            this.srRadio.Text = "Senior";
            this.srRadio.UseVisualStyleBackColor = true;
            // 
            // jrRadio
            // 
            this.jrRadio.AutoSize = true;
            this.jrRadio.Location = new System.Drawing.Point(61, 66);
            this.jrRadio.Name = "jrRadio";
            this.jrRadio.Size = new System.Drawing.Size(53, 17);
            this.jrRadio.TabIndex = 2;
            this.jrRadio.TabStop = true;
            this.jrRadio.Text = "Junior";
            this.jrRadio.UseVisualStyleBackColor = true;
            // 
            // sophRadio
            // 
            this.sophRadio.AutoSize = true;
            this.sophRadio.Location = new System.Drawing.Point(61, 42);
            this.sophRadio.Name = "sophRadio";
            this.sophRadio.Size = new System.Drawing.Size(79, 17);
            this.sophRadio.TabIndex = 1;
            this.sophRadio.TabStop = true;
            this.sophRadio.Text = "Sophomore";
            this.sophRadio.UseVisualStyleBackColor = true;
            // 
            // freshRadio
            // 
            this.freshRadio.AutoSize = true;
            this.freshRadio.Location = new System.Drawing.Point(61, 19);
            this.freshRadio.Name = "freshRadio";
            this.freshRadio.Size = new System.Drawing.Size(71, 17);
            this.freshRadio.TabIndex = 0;
            this.freshRadio.TabStop = true;
            this.freshRadio.Text = "Freshman";
            this.freshRadio.UseVisualStyleBackColor = true;
            // 
            // lastNameBox
            // 
            this.lastNameBox.Location = new System.Drawing.Point(170, 171);
            this.lastNameBox.MaxLength = 1;
            this.lastNameBox.Name = "lastNameBox";
            this.lastNameBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameBox.TabIndex = 1;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(14, 174);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(150, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Enter First Letter of Last Name";
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(105, 214);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 3;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // program2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.lastNameBox);
            this.Controls.Add(this.classGroupBox);
            this.Name = "program2";
            this.Text = "Program2";
            this.classGroupBox.ResumeLayout(false);
            this.classGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox classGroupBox;
        private System.Windows.Forms.RadioButton srRadio;
        private System.Windows.Forms.RadioButton jrRadio;
        private System.Windows.Forms.RadioButton sophRadio;
        private System.Windows.Forms.RadioButton freshRadio;
        private System.Windows.Forms.TextBox lastNameBox;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Button calcButton;
    }
}

